function iniciarDownload() {
  const barra = document.getElementById("progresso")
  const estado = document.getElementById("estado")

  clearInterval(window.intervalo)
  let progresso = 0

  window.intervalo = setInterval(() => {
    let sorteado = Math.floor(Math.random() * 5) + 1

    progresso = Math.min(progresso + sorteado, 100)
    barra.style.width = progresso + '%'
    estado.textContent = progresso + '%'

    if (progresso >= 100) {
      clearInterval(window.intervalo)
      estado.textContent = "✅ Download completo!"
    }
  }, 200)
}
