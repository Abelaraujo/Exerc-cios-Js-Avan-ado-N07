function alternarTema() {
  const body = document.body;
  const tema = body.classList.toggle("dark") ? "dark" : "light";
  localStorage.setItem("tema", tema);
}

window.onload = () => {
  const temaSalvo = localStorage.getItem("tema");
  if (temaSalvo === "dark") {
    document.body.classList.add("dark");
  }
};
