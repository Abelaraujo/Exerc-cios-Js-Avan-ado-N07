let lista = [1,[2,[3,[4]]]]

function flutter (vetor) {
    let resultado = vetor.flatMap(num => Array.isArray(num)? flutter(num): num)
    return resultado
}

console.log(flutter(lista))