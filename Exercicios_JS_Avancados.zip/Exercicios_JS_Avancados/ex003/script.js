function clonar(original) {
  if (original === null || typeof original !== 'object') return original;

  const copia = Array.isArray(original) ? [] : {};

  for (let chave in original) {
    copia[chave] = clonar(original[chave]);
  }

  return copia;
}

const original = { nome: 'João', endereco: { cidade: 'Luanda' } };
const copia = clonar(original);

copia.endereco.cidade = 'Bogotá';

console.log(`Cópia do endereço: ${copia.endereco.cidade}`);
console.log(`Endereço original: ${original.endereco.cidade}`);
