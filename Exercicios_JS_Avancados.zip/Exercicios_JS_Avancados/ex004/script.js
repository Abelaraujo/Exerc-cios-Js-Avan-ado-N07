function achatar(obj, cam = '', result = {}) {
  for (let chave in obj) {
    const valor = obj[chave]

    const novaChave = cam ? cam + '.' + chave : chave;

    if (typeof valor === 'object' && valor !== null) {
      achatar(valor, novaChave, result);
    } 
    else {
      result[novaChave] = valor
    }
  }
  return result
}

const entrada = {user: {name:"Ana",age:20}}

const saida = achatar(entrada)
console.log(saida)
