function rank(jogadores) {
  jogadores.sort((a, b) => b.pontos - a.pontos)
  jogadores.forEach((jogadores, i) => {
    console.log(`${i + 1}º ${jogadores.nome} - ${jogadores.pontos} pts`)
  })
}

const lista = [
  { nome: "Ana", pontos: 120 },
  { nome: "Carlos", pontos: 200 },
  { nome: "Beatriz", pontos: 150 }
]

rank(lista)
