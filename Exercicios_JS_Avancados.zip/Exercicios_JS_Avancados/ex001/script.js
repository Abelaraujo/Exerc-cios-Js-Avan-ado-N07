function repetidos3(valores) {
  const contador = {}

  for (let num of valores) {
    contador[num] = (contador[num] || 0) + 1
  }

  
  const ordenado = Object.entries(contador).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([numero, vezes]) => ({ numero: Number(numero), vezes }))

  return ordenado
}

console.log(repetidos3([1,1,1,2, 2, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5]))
