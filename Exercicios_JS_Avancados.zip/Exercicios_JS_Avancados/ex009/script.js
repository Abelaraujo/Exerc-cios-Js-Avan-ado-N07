function validarUsuario() {
  const txt = document.getElementById("usuario");
  const msg = document.getElementById("mensagem");

  msg.textContent = "Verificando...";
  setTimeout(() => {
    if (txt.value === "admin") {
      msg.textContent = "Nome já em uso";
      msg.style.color = "red";
    } else {
      msg.textContent = "Disponível ✅";
      msg.style.color = "green";
    }
  }, 2000);
}
