Nome completo: João Abel de Araújo Mutombo
Número: 07
Turma: II12B