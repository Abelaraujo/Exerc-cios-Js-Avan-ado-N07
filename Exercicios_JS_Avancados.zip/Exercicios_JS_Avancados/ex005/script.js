async function promises(...funcoes) {
  for (let elemento of funcoes) {
    const resultado = await elemento()
    console.log(resultado)
  }
}

const tarefa1 = () => new Promise(r => setTimeout(() => r("Primeira feita"), 1000))
const tarefa2 = () => new Promise(r => setTimeout(() => r("Segunda feita"), 500))

filaPromises(tarefa1, tarefa2)
